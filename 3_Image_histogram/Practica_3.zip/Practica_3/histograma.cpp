#include <iostream>
#include <cmath>
#include <stdio.h>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

void histograma(Mat image);
void plot(float h[]);

int main( int argc, char** argv ){

  if( argc != 2) {
    cout <<" Usage: mostrar_imagen <archivo de imagen>" << endl;
    return -1;
  }

  Mat im;
  im = imread(argv[1], 0);

  if( !im.data ) {
    cout <<  "Could not open or find the image" <<endl ;
    return -1;
  }
  
  histograma(im);
  return 0;
}

void histograma(Mat image){
//  Vector de ocurrencias o frecuencias en los niveles de grises inicializado en cero
	int h[255];
	for(int i=0; i<=255; i++)
		h[i] = 0;

//	Se obtienen el histograma de cada nivel de gris
	for(int i=0; i<image.rows; i++){
		for(int j=0; j<image.cols; j++){
				h[ image.at<Vec3b>(i,j)[0] ]++;
		}
	}
	
//  Se normaliza el histograma
	float n = pow(512,2), Hn[255];
	for(int i=0; i<255; i++)
		Hn[i] = (h[i]/n)*1000;
	
//  Se muestra el histograma en consola
	cout<<"\n\t\t HISTOGRAMA DE LA IMAGEN SELECCIONADA \n";
	for(int i=0; i<=255; i++){
		     cout<<" "<<i<<"- "<<h[i]<<" \t";
	}
	cout<<endl;
	
	plot(Hn);
}

void plot(float H[]){
	Mat image(255, 255, CV_8UC1, Scalar(255));
	int dif=0;
	
	for(int j=0; j<image.rows; j++){
		dif = 255 - H[j];
		for(int i=0; i<image.cols; i++){
			if (i >= dif ){
				image.data[i*255 + j] = 0;
			} else
				image.data[i+255 + j] = 255;
		}
	}
	
	namedWindow("Histograma de una imagen", WINDOW_AUTOSIZE);
	imshow("Histograma de una imagen", image);
	waitKey(0);

}
