#include <iostream>
#include <cstdlib>
#include <cmath>
#include <opencv2/opencv.hpp>
#include <cstdlib>
#define pi 3.14159265

using namespace std;
using namespace cv;

Mat img, imageOut;

int main(int argc, char **argv){

	img = imread(argv[1], 0 );

	if (!img.data){
		cout<<"\n Take care how typing the picture name \n"<<endl;
		return -1;
	}

	imageOut = imread("images/input.jpg", 1);
	int rows = img.rows, cols = img.cols, pixel=0;

	for(int i=0; i<rows; i++){
		for(int j=0; j<cols; j++){
			pixel = img.data[i*cols + j];

			if( pixel != 0 ){
				imageOut.data[i*3*cols + j*3 + 0] = 0;
				imageOut.data[i*3*cols + j*3 + 1] = 0;
				imageOut.data[i*3*cols + j*3 + 2] = 0;
			}
		}
	}

	plot(imageOut);

	return 0;
}

void plot(Mat image){
	namedWindow("IMAGEN DE SALIDA", 0);
	imshow("IMAGEN DE SALIDA", image);
	waitKey(0);
}

void plot2(Mat image, Mat newImage){
	namedWindow("Imagen de entrada en escala de grises", 0);
	imshow("Imagen de entrada en escala de grises", image);
	waitKey(0);

	namedWindow("Bordes de la imagen utilizando el método de Canny", 0);
	imshow("Bordes de la imagen utilizando el método de Canny", newImage);
	waitKey(0);
}
