#include <iostream>
#include <stdio.h>
#include <cmath>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

void histograma(Mat im);
void ajuste_lineal(Mat image);
void ecualizacion(Mat image, float Hn[]);
void plot(float H[]);
void plotEq(float H[]);

int main( int argc, char** argv ){

	if( argc != 2) {
	cout <<" Type currently the picture name and extension " << endl;
	return -1;
	}

	Mat im;
	im = imread(argv[1], 0);
	
	if( !im.data ) {
	cout <<" Take care how type the picture name" <<endl ;
	return -1;
	}

	histograma(im);
//	ajuste_lineal(im);
	
	return 0;
}

void histograma(Mat image){
//  Vector del histograma inicializado en cero
	int h[256];
	for(int i=0; i<256; i++)
		h[i] = 0;

//	Se obtienen la ocurrencia de cada nivel de gris
	int num=0;
	for(int j=0; j<image.cols; j++){
		for(int i=0; i<image.rows; i++){
			num = image.data[i*image.cols + j];
			h[num]++;
		}
	}
	
//  Se normaliza y redondea el histograma 
	float n = (image.rows)*(image.cols), Hn[256];
	int porc=255*35;
	
	for(int i=0; i<256; i++){
		if( ((h[i]/n)*porc)-floor((h[i]/n)*porc) < ceil((h[i]/n)*porc)-((h[i]/n)*porc) )
			Hn[i] = floor((h[i]/n)*porc);
		  else
		    Hn[i] = ceil((h[i]/n)*porc);
	}
	
	plot(Hn);
	ecualizacion(image, Hn);
}

void ajuste_lineal(Mat image){
	int Inmin, Inmax, factor, rows=image.rows, cols=image.cols, channels=image.channels();
	Mat newImage = image.clone();
	
	cout<<"\n Valor mínimo = ";cin>>Inmin;
	cout<<" Valor máximo = ";cin>>Inmax;
	factor = 255/(Inmax-Inmin);
	
	for(int j=0; j<rows; j++){
		for(int i=0; i<cols; i++){
			if( (newImage.data[j*cols+i]-Inmin)*factor > 255 )
				newImage.data[j*cols+i] = 255;
				else if( (image.data[j*cols+i]-Inmin)*factor < 0 )
					newImage.data[j*cols+i] = 0;
				else
					newImage.data[j*cols+i] = (newImage.data[j*cols+i]-Inmin)*factor;
		}
	}
	
	namedWindow("Imagen original", WINDOW_AUTOSIZE);
	imshow("Imagen original", image);
	waitKey(0);	
	namedWindow("Imagen corregida", WINDOW_AUTOSIZE);
	imshow("Imagen corregida", newImage);
	waitKey(0);
	histograma(newImage);
}

void ecualizacion(Mat image, float Hn[]){
	float Ha[256];
//	Copia del histograma normalizado
	for(int i=0; i<256; i++){
		Ha[i] = Hn[i];
	}
//	Histograma acumulado
	for(int i=0; i<256; i++){
		if( i==0 )
			Ha[0] = 0;
		  else
			Ha[i] = (Ha[i-1] + Ha[i]);
	}
//	Normalizo el histograma acumulado
	int fact=255;
	for(int i=0; i<256; i++){
		Ha[i] = fact*(Ha[i]/Ha[255]);
	}
	
	plotEq(Ha);
	
	float T[256], dimension=0;
	dimension = (image.rows)*image.cols;
	
	for(int i=0; i<256; i++){
		if( (fact*(255/dimension)*(Ha[i]))-floor(fact*(255/dimension)*(Ha[i])) < ceil(fact*(255/dimension)*(Ha[i]))-(fact*(255/dimension)*(Ha[i])) )
			T[i] = floor(fact*(255/dimension)*(Ha[i]));
		  else
		    T[i] = ceil(fact*(255/dimension)*(Ha[i]));
	}

	cout<<endl<<endl;
	for(int i=0; i<256; i++){
		cout<<i<<"- "<<T[i]<<"\t\t";
	}
	cout<<endl<<endl;

	plotEq(T);
}

void plot(float H[]){
	Mat image(280, 256, CV_8UC1, Scalar(255));
	int dif=0;
	
	for(int j=0; j<image.cols; j++){
		dif = 256 - H[j];
		for(int i=0; i<image.rows; i++){
			if(i >= dif && i <= image.rows-25){
				image.data[i*image.cols + j] = 0;
			  }else{
				 if(i > image.rows-25 && i <= image.rows-20 )
				    image.data[i*image.cols + j] = 220;
				 else if(i > image.rows-20 )
					image.data[i*image.cols + j] = j;
			}
		}
		dif=0;
	}
	
	cout<<"\n\n";
	namedWindow("Histogramas", WINDOW_AUTOSIZE);	
	imshow("Histogramas", image);
	waitKey(0);
}

void plotEq(float H[]){
	Mat image(280, 256, CV_8UC1, Scalar(255));
	int dif=0;
	
	for(int j=0; j<image.cols; j++){
		dif = 255 - H[j];
		for(int i=0; i<image.rows; i++){
			if(i == dif && i <= image.rows-25){
				image.data[i*image.cols + j] = 0;
			  }else{
				 if(i > image.rows-25 && i <= image.rows-20 )
				    image.data[i*image.cols + j] = 220;
				 else if(i > image.rows-20 )
					image.data[i*image.cols + j] = j;
			}
		}
		dif=0;
	}
	
	cout<<"\n\n";
	namedWindow("Histograma acumulado", WINDOW_AUTOSIZE);	
	imshow("Histograma acumulado", image);
	waitKey(0);
}


