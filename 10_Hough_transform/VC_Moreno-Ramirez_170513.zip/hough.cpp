#include <iostream>
#include <cstdlib>
#include <cmath>
#include <opencv2/opencv.hpp>
#define pi 3.14159265

using namespace std;
using namespace cv;

Mat img, imageOut;

void hough();
void plot(Mat in);
void plot2(Mat in, Mat out);
void plot3(Mat in1, Mat in2, Mat in3);

int main(int argc, char **argv){

	img = imread(argv[1], 0 );

	if (!img.data){
		cout<<"\n Take care how typing the picture name \n"<<endl;
		return -1;
	}

	img.copyTo(imageOut);

	hough();

	return 0;
}

void hough(){
//	VARIABLE A UTILIZAR
	int rows = img.rows, cols = img.cols, dMaxima = round(sqrt( pow(rows,2) + pow(cols,2) )), grados=360;
	int rowsCollector = dMaxima, polar[rowsCollector][grados];
	int imgIn[rows][cols];

	cout<<"\n Filas = "<<rows<<" Columnas = "<<cols<<endl;
//	INICIALIZACION DE ARREGLOS QUE ALMACENAN LAS CURVAS SINUSOIDALES EN EL PLANO POLAR
	for (int i=0; i<rowsCollector; i++)
		for (int j=0; j<grados; j++)
			polar[i][j] = 0;

//	SE BUSCA EN LA IMAGEN UN PUNTO NEGRO, QUE REPRESENTA UN BORDE, AL ENCONTRARLO SE CREAN LAS CURVAS SINUSOIDALES EN EL PLANO POLAR
//	Y SE VAN AGREGANDO EN FORMA DE INCREMENTO A LOS ARREGLOS, CONSIDERANDO LOS VALORES NEGATIVOS Y POSITIVOS QUE PUEDEN RESULTAR
//	DE APLICAR LA EXTRAPOLACION A COORDENADAS POLARES CON UN INTERVALO DE [0, 180)
//	SE OBTIENE EL VALOR MAYOR QUE INDICA EL CRUCE DE VARIAS CURVAS POR EL MISMO PUNTO DEL PLANO POLAR, ESTO NOS DA UN PUNTO EN COMUN Y,
//	UN PUNTO EN EL PLANO POLAR ES IGUAL A UNA RECTA EN EL PLANO CARTESIANO
	int mayor=0, x=0, y=0, p=0, pixel=0;
	for (int i=0; i<rows; i++)
	for (int j=0; j<cols; j++){

		imgIn[i][j] = 0;
		pixel = img.data[i*cols + j];

		if ( pixel > 0 ){
			for (int theta=0; theta<grados; theta++){
				p = i*cos((theta*pi)/180) + j*sin((theta*pi)/180);

				if ( p >= 0 ){
					polar[p][theta]++;

					if( polar[p][theta] > mayor ){
						mayor = polar[p][theta];

						x = i; y = j;
					}
				}

			}
		}
		imgIn[i][j] = img.data[i*cols + j];
	}

	cout<<endl<<"\n\n Valor mayor = "<<mayor<<"\n Con coordenadas x-y ("<<x<<","<<y<<")  "<<endl<<endl<<endl;

//	OBTENEMOS SOLO LOS PUNTOS QUE ESTAN POR ENCIMA DEL 80% DEL VALOR PARA EL PUNTO MAXIMO EN EL ACUMULADOR
	int umbral = 100; //round(0.8*mayor);
	cout<<"\n RECTAS MAXIMAS EN COORDENADAS (ro,theta) \n"<<endl;
	cout<<" Umbral = "<<umbral<<endl<<endl;

	for (int i=0; i<rowsCollector; i++){
		for (int j=0; j<grados; j++){
			if ( polar[i][j] >= umbral ){
				polar[i][j] = 255;
				cout<<" ("<<i<<","<<j<<")"<<endl;
			}else
				polar[i][j] = 0;
		}
	}
	cout<<endl<<endl;

//	OBTENEMOS RECTAS EN EL PLANO X-Y, A PARTIR DE PUNTOS EN EL PLANO RO-THETA
	int Y=0;
	for (int ro=0; ro<rowsCollector; ro++)
	for (int theta=0; theta<grados; theta++){
		if( polar[ro][theta] == 255 ){
			for (int x=0; x<rows; x++)
				if ( sin((theta*pi)/180) > 0 ){
					Y = ( ro - x*cos((theta*pi)/180) )/sin((theta*pi)/180);

					if( Y >= 0 && Y < cols )
						imgIn[x][Y] = 255;
				}
		}
	}

//	SE PASAN LOS DATOS DEL ACUMULADOR A UNA IMAGEN
	Mat Polar(rowsCollector, grados, CV_8UC1, Scalar(255));

	for (int i=0; i<rowsCollector; i++)
		for (int j=0; j<grados; j++){
			Polar.data[i*grados + j] -= polar[i][j];
		}

	Mat lineas(rows, cols, CV_8UC1, Scalar(0));
	for (int i=0; i<rows; i++)
		for(int j=0; j<cols; j++){
			lineas.data[i*cols + j] = imgIn[i][j];
		}

//	SE MUESTRA TANTO LA IMAGEN DE PUNTOS EN UN PLANO CARTESIANO COMO SU SIMILAR EN EL PLANO POLAR
	plot(lineas);
}

void plot(Mat in){
	namedWindow("Solo una imagen de salida", 0);
	imshow("Solo una imagen de salida", in);
	waitKey(0);
}

void plot2(Mat in, Mat out){
	namedWindow("IMAGEN DE ENTRADA", 0);
	imshow("IMAGEN DE ENTRADA", in);
	waitKey(0);

	namedWindow("IMAGEN DE SALIDA CON LA RECTA PREDOMINANTE", 0);
	imshow("IMAGEN DE SALIDA CON LA RECTA PREDOMINANTE", out);
	waitKey(0);
}

void plot3(Mat in1, Mat in2, Mat in3){
	namedWindow("IMAGEN DE ENTRADA", WINDOW_AUTOSIZE);
	imshow("IMAGEN DE ENTRADA", in1);
	waitKey(0);

	namedWindow("CURVAS SINUSOIDALES DE CADA PUNTO DE LA IMAGEN DE ENTRADA", WINDOW_AUTOSIZE);
	imshow("CURVAS SINUSOIDALES DE CADA PUNTO DE LA IMAGEN DE ENTRADA", in2);
	waitKey(0);

	namedWindow("IMAGEN DE SALIDA, RECTA PREDOMINANTE", WINDOW_AUTOSIZE);
	imshow("IMAGEN DE SALIDA, RECTA PREDOMINANTE", in3);
	waitKey(0);
}

